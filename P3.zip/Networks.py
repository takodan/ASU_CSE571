import torch
import torch.nn as nn
from Data_Loaders import *

class Action_Conditioned_FF(nn.Module):
    def __init__(self, input_size=6, hidden_size = 4, output_size=1):
# STUDENTS: __init__() must initiatize nn.Module and define your network's
# custom architecture
        super(Action_Conditioned_FF, self).__init__()
        self.input_to_hidden = nn.Linear(input_size, hidden_size)
        self.nonlinear_activation = nn.Sigmoid()
        self.hidden_to_output = nn.Linear(hidden_size, output_size)


    def forward(self, input):
# STUDENTS: forward() must complete a single forward pass through your network
# and return the output which should be a tensor
        hidden = self.input_to_hidden(input)
        hidden = self.nonlinear_activation(hidden)
        output = self.hidden_to_output(hidden)
        return output


    def evaluate(self, model, test_loader, loss_function):
# STUDENTS: evaluate() must return the loss (a value, not a tensor) over your testing dataset. Keep in
# mind that we do not need to keep track of any gradients while evaluating the
# model. loss_function will be a PyTorch loss function which takes as argument the model's
# output and the desired output.
        total_lost = 0
        with torch.no_grad():
            for data in test_loader:
                network_input, targets_outputs = data['input'], data['label']
                outputs = model(network_input)
                targets_outputs = targets_outputs.unsqueeze(1)
                loss = loss_function(outputs, targets_outputs)
                total_lost += loss.item()
        return total_lost

def main():
    batch_size = 16
    data_loaders = Data_Loaders(batch_size)
    model = Action_Conditioned_FF()
    loss_function = nn.MSELoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    training_step = 0
    epoch = 1
    for i in range(epoch):
        for train in data_loaders.train_loader:
            network_input, targets_outputs = train['input'], train['label']
            network_outputs = model(network_input)

            loss = loss_function(network_outputs, targets_outputs)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            training_step += 1
            print("training step: {}, loss: {}".format(training_step, loss.item()))

        
        testing_loss = model.evaluate(model, data_loaders.test_loader, loss_function)
        print(testing_loss)




if __name__ == '__main__':
    main()
