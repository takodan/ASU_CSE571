import torch
import torch.nn as nn
from Data_Loaders import *


class Action_Conditioned_FF(nn.Module):
    def __init__(self):
# STUDENTS: __init__() must initiatize nn.Module and define your network's
# custom architecture
        # 設定每一層網路大小架構
        super(Action_Conditioned_FF, self).__init__()
        input_size = 6
        hidden_size = 32
        output_size = 1
        self.fc_layer1 = nn.Linear(input_size, hidden_size)
        self.fc_layer2 = nn.Linear(hidden_size, hidden_size)
        self.fc_layer3 = nn.Linear(hidden_size, output_size)
        self.nonlinear_activation = nn.ReLU() # nn.ReLU() nn.Sigmoid() nn.Tanh()

    def forward(self, input):
# STUDENTS: forward() must complete a single forward pass through your network
# and return the output which should be a tensor
        # 設定層的排列方式
        hidden = input
        hidden = self.fc_layer1(hidden)
        hidden = self.nonlinear_activation(hidden)
        hidden = self.fc_layer2(hidden)
        hidden = self.nonlinear_activation(hidden)
        hidden = self.fc_layer2(hidden)
        hidden = self.nonlinear_activation(hidden)
        hidden = self.fc_layer3(hidden)
        output = hidden
        return output


    def evaluate(self, model, test_loader, loss_function):
# STUDENTS: evaluate() must return the loss (a value, not a tensor) over your testing dataset. Keep in
# mind that we do not need to keep track of any gradients while evaluating the
# model. loss_function will be a PyTorch loss function which takes as argument the model's
# output and the desired output.
        total_lost = 0
        # 取消梯度
        with torch.no_grad():
            # 讀取資料
            for test_data in test_loader:
                # 拆分資料中的input和label
                network_input = test_data['input']
                target_outputs = test_data['label']
                # 輸入input到模型中
                outputs = model(network_input)
                # 計算損失
                target_outputs = target_outputs.unsqueeze(1)
                loss = loss_function(outputs, target_outputs)

                total_lost = total_lost + loss.item()
            averge_loss = total_lost/len(test_loader)
        return averge_loss

def main():
    batch_size = 16
    data_loaders = Data_Loaders(batch_size)
    # 創建網路模型
    model = Action_Conditioned_FF()
    # 損失函數
    loss_function = nn.MSELoss() # nn.MSELoss()
    # 優化器
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4) # SGD Adam

    print(model)
    training_step = 0
    epoch = 500
    for i in range(epoch):
        print("-----第{}輪訓練-----".format(i+1))
        # 讀取資料
        for train_data in data_loaders.train_loader:
            # 拆分資料中的input和label
            network_input, targets_outputs = train_data['input'], train_data['label']
            # 輸入input到模型中
            network_outputs = model(network_input)
            # 計算損失
            targets_outputs = targets_outputs.unsqueeze(1)
            loss = loss_function(network_outputs, targets_outputs)
            # 優化權重
            # if i == 100 :
            #     optimizer = torch.optim.SGD(model.parameters(), lr=1e-4)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 顯示總訓練次數和每次的loss
            training_step += 1
            if training_step%500 == 0:
                print("training step: {}, loss: {}".format(training_step, loss.item()))
                # print(model.fc_layer1.weight.data.norm())

        
        averge_loss = model.evaluate(model, data_loaders.test_loader, loss_function)
        print("第{}輪測試集內的平均損失: {}".format(i+1, averge_loss))
        # print(model.rnn_layer.weight_ih.data.norm(), model.fc_layer3.weight.data.norm())

    torch.save(model.state_dict(), "assignment_part4/grader/saved//saved_modelLNN32_4_500_11k.pkl")



if __name__ == '__main__':
    main()
